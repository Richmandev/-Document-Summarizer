import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";

export async function POST(request: NextRequest) {
  try {
    const { content } = await request.json();

    if (!content || typeof content !== "string") {
      return NextResponse.json(
        { error: "Content is required" },
        { status: 400 }
      );
    }

    const zai = await ZAI.create();

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: "system",
          content: `You are an AI assistant designed to help students understand long documents quickly.

Your task is to read the content provided by the user and produce a clear, structured response in English with the following format:

1) Short Summary  
- Write a concise summary in 3–5 bullet points.  
- Each bullet point should be short and easy to read.

2) Simple Explanation  
- Explain the main idea in very simple language, as if explaining to a high school student.  
- Keep it short and easy to understand.

3) Key Takeaways  
- List 3 important takeaways from the content.  
- Focus on practical or useful points for students.

Rules:
- Use clear and simple English.  
- Do not add information that is not in the content.  
- Do not use long paragraphs.  
- Keep the total response short and well-structured.`
        },
        {
          role: "user",
          content: content
        }
      ],
      temperature: 0.7,
      max_tokens: 1500
    });

    const summary = completion.choices[0]?.message?.content;

    if (!summary) {
      return NextResponse.json(
        { error: "Failed to generate summary" },
        { status: 500 }
      );
    }

    return NextResponse.json({ summary });

  } catch (error: unknown) {
    console.error("Summarization error:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json(
      { error: `Failed to process request: ${errorMessage}` },
      { status: 500 }
    );
  }
}
