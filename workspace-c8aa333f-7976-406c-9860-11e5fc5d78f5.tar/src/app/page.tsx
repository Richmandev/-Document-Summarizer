'use client'

import { useState } from 'react'

const sampleContents = [
  {
    title: "🔬 Photosynthesis",
    content: `Photosynthesis is the process by which plants convert sunlight into energy. This process occurs in the chloroplasts of plant cells, which contain a green pigment called chlorophyll. During photosynthesis, plants take in carbon dioxide from the air through small pores called stomata, and absorb water from the soil through their roots. Using energy from sunlight, the plant converts these ingredients into glucose (sugar) and oxygen. The glucose serves as food for the plant, providing energy for growth and other functions. The oxygen is released into the atmosphere as a byproduct. This process is essential for life on Earth because it produces the oxygen that humans and animals need to breathe. Additionally, photosynthesis forms the base of most food chains, as plants are the primary producers that other organisms depend on for food. Scientists have studied photosynthesis extensively to understand how plants work and to develop technologies like artificial photosynthesis that could help address energy needs and climate change.`
  },
  {
    title: "🏭 Industrial Revolution",
    content: `The Industrial Revolution was a period of major industrialization that took place during the late 1700s and early 1800s. It began in Great Britain and eventually spread to other parts of Europe and the United States. Before this period, most people lived in rural areas and worked as farmers or craftsmen. The Industrial Revolution changed this dramatically. New inventions like the steam engine, spinning jenny, and power loom made it possible to produce goods much faster than before. Factories were built, and people moved from farms to cities to work in these factories. This led to the growth of urban areas and the development of new social classes. However, the Industrial Revolution also brought problems. Factory workers often worked long hours in dangerous conditions for low wages. Children were frequently employed in factories because they could be paid less. Pollution from factories damaged the environment. Over time, labor laws were created to protect workers, and living conditions in cities improved. The Industrial Revolution fundamentally changed how people lived and worked, and its effects continue to influence our world today.`
  },
  {
    title: "🤖 Artificial Intelligence",
    content: `Artificial Intelligence, or AI, refers to computer systems designed to perform tasks that normally require human intelligence. These tasks include learning, problem-solving, understanding language, and recognizing patterns. AI works by processing large amounts of data and finding patterns within that data. Machine learning, a type of AI, allows computers to learn from experience without being explicitly programmed. For example, when you use a streaming service and it recommends movies based on what you've watched before, that's AI at work. AI is used in many applications today, from virtual assistants like Siri and Alexa to self-driving cars and medical diagnosis systems. While AI offers many benefits, such as improving efficiency and helping solve complex problems, it also raises important questions. Some people worry about AI replacing human jobs, the spread of misinformation through AI-generated content, and privacy concerns related to data collection. As AI technology continues to advance, society will need to address these challenges while maximizing the benefits AI can provide.`
  }
]

export default function Home() {
  const [content, setContent] = useState('')
  const [summary, setSummary] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')

  const handleSummarize = async () => {
    if (!content.trim()) {
      setError('Please enter some content to summarize')
      return
    }

    setIsLoading(true)
    setError('')
    setSummary('')

    try {
      const response = await fetch('/api/summarize', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ content }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || 'Failed to generate summary')
      }

      setSummary(data.summary)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred')
    } finally {
      setIsLoading(false)
    }
  }

  const handleSampleClick = (sampleContent: string) => {
    setContent(sampleContent)
    setSummary('')
    setError('')
  }

  const handleClear = () => {
    setContent('')
    setSummary('')
    setError('')
  }

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      padding: '2rem 1rem',
    }}>
      <div style={{
        maxWidth: '900px',
        margin: '0 auto',
      }}>
        {/* Header */}
        <div style={{
          textAlign: 'center',
          marginBottom: '2rem',
        }}>
          <h1 style={{
            fontSize: '2.5rem',
            fontWeight: 'bold',
            color: 'white',
            marginBottom: '0.5rem',
            textShadow: '0 2px 4px rgba(0,0,0,0.1)',
          }}>
            📚 Document Summarizer
          </h1>
          <p style={{
            color: 'rgba(255,255,255,0.9)',
            fontSize: '1.1rem',
          }}>
            AI-powered assistant to help students understand documents quickly
          </p>
        </div>

        {/* Main Card */}
        <div style={{
          background: 'white',
          borderRadius: '1rem',
          boxShadow: '0 20px 40px rgba(0,0,0,0.15)',
          overflow: 'hidden',
        }}>
          {/* Sample Buttons */}
          <div style={{
            padding: '1.5rem',
            borderBottom: '1px solid #e5e7eb',
            background: '#f9fafb',
          }}>
            <p style={{
              fontSize: '0.875rem',
              color: '#6b7280',
              marginBottom: '0.75rem',
              fontWeight: '500',
            }}>
              ✨ Quick Test with Sample Content:
            </p>
            <div style={{
              display: 'flex',
              flexWrap: 'wrap',
              gap: '0.5rem',
            }}>
              {sampleContents.map((sample, index) => (
                <button
                  key={index}
                  onClick={() => handleSampleClick(sample.content)}
                  style={{
                    padding: '0.5rem 1rem',
                    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                    color: 'white',
                    border: 'none',
                    borderRadius: '2rem',
                    cursor: 'pointer',
                    fontSize: '0.875rem',
                    fontWeight: '500',
                    transition: 'transform 0.2s, box-shadow 0.2s',
                  }}
                  onMouseOver={(e) => {
                    e.currentTarget.style.transform = 'translateY(-2px)'
                    e.currentTarget.style.boxShadow = '0 4px 12px rgba(102, 126, 234, 0.4)'
                  }}
                  onMouseOut={(e) => {
                    e.currentTarget.style.transform = 'translateY(0)'
                    e.currentTarget.style.boxShadow = 'none'
                  }}
                >
                  {sample.title}
                </button>
              ))}
            </div>
          </div>

          {/* Text Input Area */}
          <div style={{ padding: '1.5rem' }}>
            <label style={{
              display: 'block',
              fontSize: '0.875rem',
              fontWeight: '600',
              color: '#374151',
              marginBottom: '0.5rem',
            }}>
              📝 Enter Your Content:
            </label>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Paste your document content here, or click a sample button above..."
              style={{
                width: '100%',
                minHeight: '200px',
                padding: '1rem',
                border: '2px solid #e5e7eb',
                borderRadius: '0.5rem',
                fontSize: '1rem',
                lineHeight: '1.6',
                resize: 'vertical',
                outline: 'none',
                transition: 'border-color 0.2s',
                boxSizing: 'border-box',
                fontFamily: 'inherit',
              }}
              onFocus={(e) => {
                e.target.style.borderColor = '#667eea'
              }}
              onBlur={(e) => {
                e.target.style.borderColor = '#e5e7eb'
              }}
            />

            {/* Action Buttons */}
            <div style={{
              display: 'flex',
              gap: '1rem',
              marginTop: '1rem',
            }}>
              <button
                onClick={handleSummarize}
                disabled={isLoading || !content.trim()}
                style={{
                  flex: 1,
                  padding: '0.875rem 1.5rem',
                  background: isLoading || !content.trim() 
                    ? '#9ca3af' 
                    : 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                  color: 'white',
                  border: 'none',
                  borderRadius: '0.5rem',
                  cursor: isLoading || !content.trim() ? 'not-allowed' : 'pointer',
                  fontSize: '1rem',
                  fontWeight: '600',
                  transition: 'all 0.2s',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '0.5rem',
                }}
              >
                {isLoading ? (
                  <>
                    <span style={{
                      display: 'inline-block',
                      width: '1rem',
                      height: '1rem',
                      border: '2px solid rgba(255,255,255,0.3)',
                      borderTopColor: 'white',
                      borderRadius: '50%',
                      animation: 'spin 1s linear infinite',
                    }} />
                    Processing...
                  </>
                ) : (
                  <>🚀 Summarize</>
                )}
              </button>
              <button
                onClick={handleClear}
                style={{
                  padding: '0.875rem 1.5rem',
                  background: '#f3f4f6',
                  color: '#374151',
                  border: 'none',
                  borderRadius: '0.5rem',
                  cursor: 'pointer',
                  fontSize: '1rem',
                  fontWeight: '600',
                  transition: 'background 0.2s',
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.background = '#e5e7eb'
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.background = '#f3f4f6'
                }}
              >
                Clear
              </button>
            </div>

            {/* Error Message */}
            {error && (
              <div style={{
                marginTop: '1rem',
                padding: '1rem',
                background: '#fef2f2',
                border: '1px solid #fecaca',
                borderRadius: '0.5rem',
                color: '#dc2626',
              }}>
                ⚠️ {error}
              </div>
            )}
          </div>

          {/* Summary Result */}
          {summary && (
            <div style={{
              padding: '1.5rem',
              background: 'linear-gradient(135deg, #f0fdf4 0%, #ecfdf5 100%)',
              borderTop: '3px solid #10b981',
            }}>
              <h2 style={{
                fontSize: '1.25rem',
                fontWeight: 'bold',
                color: '#065f46',
                marginBottom: '1rem',
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
              }}>
                ✅ Summary Result
              </h2>
              <div style={{
                background: 'white',
                padding: '1.5rem',
                borderRadius: '0.5rem',
                border: '1px solid #d1fae5',
                whiteSpace: 'pre-wrap',
                lineHeight: '1.8',
                fontSize: '0.95rem',
                color: '#1f2937',
              }}>
                {summary}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div style={{
          textAlign: 'center',
          marginTop: '2rem',
          color: 'rgba(255,255,255,0.8)',
          fontSize: '0.875rem',
        }}>
          <p>Made with ❤️ for students everywhere</p>
        </div>
      </div>

      {/* CSS Animation for spinner */}
      <style jsx global>{`
        @keyframes spin {
          to {
            transform: rotate(360deg);
          }
        }
      `}</style>
    </div>
  )
}
